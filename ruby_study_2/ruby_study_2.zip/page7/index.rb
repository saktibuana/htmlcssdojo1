# Tuis ulang hash berikut ini dengan menggunakan simbol-simbol
exam = {:subject => "Matematika", :score => 80}

# Cetak nilai dari element dengan simbol :score
puts exam [:score]