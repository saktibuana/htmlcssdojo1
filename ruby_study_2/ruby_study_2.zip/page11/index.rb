# Tetapkan sebuah daftar dari hash-hash kedalam variable `exams`
exams = [{subject: "Matematika", score: 80} , {subject: "Ilmu Pengetahuan Alam", score: 55}]

# Cetak element pada indeks 1
puts exams [1]
