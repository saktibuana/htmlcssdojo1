# Tetapkan sebuah daftar dari bahasa-bahasa pada variable `languages`
languages =["Jepang","Inggris", "Spanyol"]

# Cetak variable `languages`
puts languages
