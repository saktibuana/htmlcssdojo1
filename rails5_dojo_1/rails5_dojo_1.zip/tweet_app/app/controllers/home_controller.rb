class HomeController < ApplicationController
  def top
  end
end
