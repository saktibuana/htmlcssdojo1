# Import menu.rb
require "./menu"
# Pindahkan class Menu ke menu.rb

# Jangan pindahkan baris code berikut ini
menu1 = Menu.new(name: "Sushi", price: 10)

puts menu1.info
