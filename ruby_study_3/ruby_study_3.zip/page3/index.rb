def introduce(name)
  puts "Halo"
  puts "Nama saya adalah #{name}"
end

# Panggil method `introduce` dengan nama Anda sendiri
introduce("Betty")
