def print_info(item)
  puts "Selamat datang di Toko Elektronik Ninja!"
  puts "#{item} sedang diskon hari ini!"
end

print_info("Headphone")

# Hapus baris code berikut

