def introduce
  puts "Halo"
  puts "Saya adalah Ninja Ken"
 puts "Saya berusia 14 tahun"
  
end

puts "-----Perkenalan diri-----"
puts introduce

