require "date"

# Tetapkan nilai `return` dari `Date.today` pada variable `today`
today = Date.today

# Cetak variable `today`
puts today

# Panggil method `sunday?` milik `today`, lalu cetaklah nilai `return`-nya
puts today.sunday?