require "./menu"

class Drink < Menu
  attr_accessor :volume
end
