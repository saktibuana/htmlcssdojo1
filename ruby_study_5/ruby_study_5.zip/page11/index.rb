# Lakukan `import` class `Date` menggunakan `require`
require "date"

# Tetapkan sebuah instance dari Date pada variable `birthday`
birthday = Date.new(1996, 3, 1)

# Cetak variable `birthday`
puts birthday

# Cetak nilai `return` dari method instance `sunday?` dari variable `birthday`
puts birthday.sunday?
