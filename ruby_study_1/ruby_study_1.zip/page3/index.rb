# Cetak 37 sebagai sebuah integer
puts 37

# Cetak penjumlahan dari 2 dan 9

puts 2+9
# Cetak "2 + 9" sebagai sebuah string

puts "2+9"