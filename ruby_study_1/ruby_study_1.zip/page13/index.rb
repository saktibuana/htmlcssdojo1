score = 80

# Cetak hasil dari `score > 80`
puts score > 80

# Cetak hasil dari `score <= 80`
puts score <= 80


# Jika `score` kurang dari atau sama dengan 80, cetak "Anda bisa lebih baik lagi!"
if score <= 80
  puts "Anda bisa lebih baik lagi!"
end
