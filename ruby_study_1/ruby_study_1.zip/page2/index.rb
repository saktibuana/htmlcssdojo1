# Cetak "Hello Ruby"
puts "Hello Ruby"

# Jadikan baris berikut ini menjadi sebuah baris komentar
#puts "Hello Progate"
